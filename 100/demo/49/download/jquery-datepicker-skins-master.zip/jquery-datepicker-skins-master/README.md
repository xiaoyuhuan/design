jquery-datepicker-skins
=========

CSS3 skins for jQuery UI datepicker.

To use them, start by copying the `.datepicker.css` files you need as well as the images in the `images` folder. Then add the appropriate classes to your datepickers. See below for a complete list of the available skins.

Check `index.html` for examples.

Skins available so far:

- melon
- latoja
- lugo
- siena
- santiago
- vigo
- nigran
- cangas

Thank you to all the designers at [365psd](http://365psd.com/) for the free PSDs, and of course to [jQuery](http://jquery.com/), and [jQuery UI](http://jqueryui.com/).

Licence: FREE
